<?php
$mahasiswa = [
    [
        "nama" => "Adellia Findiana Sari",
        "email" => "adelliafindianasari@email.com",
        "prodi" => "Sistem Informasi",
        "gambar" => "adellia.jpg"
    ],
    [
        "nama" => "Rizfa Alfiqri",
        "email" => "rizfaalfiqri0427@email.com",
        "prodi" => "Sistem Informasi",
        "gambar" => "rizfa.jpg"
    ],
    [
        "nama" => "Riska Nuranisa",
        "email" => "riskanuranisa20@email.com",
        "prodi" => "Sistem Informasi",
        "gambar" => "riska.jpg"
    ],
    [
        "nama" => "Fitri Handayani",
        "email" => "hndaynif@email.com",
        "prodi" => "Sistem Informasi",
        "gambar" => "fitri.jpg"
    ],
    [
        "nama" => "Zeni Amelia",
        "email" => "zeniamelia@email.com",
        "prodi" => "Sistem Informasi",
        "gambar" => "zeni.jpg"
    ]
];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Latihan 5b - Daftar Mahasiswa</title>
    <style>
        .card {
            background: ivory;
            width: 300px;
            margin: 20px auto;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 0 10px #ccc;
        }
        img {
            border-radius: 50%;
            width: 100px;
            height: 100px;
        }
        a {
            display: block;
            font-size: 18px;
            margin-top: 10px;
            color: teal;
            text-decoration: none;
        }
    </style>
</head>
<body>

<h2 align="center">Daftar Mahasiswa Kelas 2 SI</h2>

<?php foreach ($mahasiswa as $mhs): ?>
    <div class="card">
        <img src="img/<?= $mhs['gambar']; ?>" alt="<?= $mhs['nama']; ?>">
        <a href="Latihan 5c.php?nama=<?= urlencode($mhs['nama']); ?>&email=<?= urlencode($mhs['email']); ?>&prodi=<?= urlencode($mhs['prodi']); ?>&gambar=<?= urlencode($mhs['gambar']); ?>">
            <?= $mhs['nama']; ?>
        </a>
    </div>
<?php endforeach; ?>

</body>
</html>
