<!DOCTYPE html>
<html>
<head>
    <title>Admin</title>
    <style>
        .container {
            width: 400px;
            margin: 50px auto;
            padding: 20px;
            border: 1px solid #ccc;
            text-align: center;
            box-shadow: 0 0 10px #ddd;
        }
        .logout {
            float: right;
            background: crimson;
            color: white;
            border: none;
            padding: 5px 10px;
            text-decoration: none;
        }
    </style>
</head>
<body>

<div class="container">
    <a href="logout.php" class="logout">Logout</a>
    <h2>Selamat Datang,  Admin</h2>
    <p>Ini adalah halaman admin</p>
</div>

</body>
</html>
