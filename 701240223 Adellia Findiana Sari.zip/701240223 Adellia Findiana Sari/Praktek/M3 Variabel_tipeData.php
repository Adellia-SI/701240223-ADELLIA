<?php

$nrp = "701240223";
$nama = "Adellia Findiana Sari";
$umur = 19;
$nilai = 95.95;

echo "Nrp : " . $nrp . "</br>";
echo "Nama : " . $nama . "</br>";
print "Umur : " . $umur . "</br>";
printf ("Nilai : %.3f</br>", $nilai);

?>