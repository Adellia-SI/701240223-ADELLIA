<?php

$hari = ["Senin", "Selasa"];

print_r($hari);
echo "</br>";
$haari[] = "Rabu";
print_r($hari);
echo "</br>";
$hari[3] = "Kamis";


print_r($hari);

?>