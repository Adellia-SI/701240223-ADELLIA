<?php
echo strlen ("Adellia Findiana Sari");
echo "</br>";
echo date ("d - M - Y");
echo "</br>";
echo htmlspecialchars("<img src='img.jpg'>", ENT_NOQUOTES);
?>