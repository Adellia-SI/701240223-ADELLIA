<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contoh Request Post</title>
</head>
<body>
    <form action = "M7 selamat_datang.php" method="post">
        <label for="name"> Nama anda : </label>
        <input type="text" name="nama-anda" id="nama">
        <br>
        <button type="submit" name="submit">Kirim</button>
    </form>
</body>
</html>